const { openDatabase } = require('./src/db');
const { createApp } = require('./src/app');

const db = openDatabase();
const port = process.env.PORT || 3000;
createApp(db).listen(port, () => console.log(`Inventory Tracker running at http://localhost:${port}`));

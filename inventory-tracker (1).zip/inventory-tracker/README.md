# Inventory Tracker — DPMG Group 7 prototype

Web app for BoM master data, stock in/out, safety-stock monitoring and automatic purchase orders (BRD v1.1 / SDD v1.0).

## Run

```bash
npm install
npm run seed     # optional: loads 6 demo BoMs for the BRD §8 happy path
npm start        # http://localhost:3000
npm test         # 12 tests traced to INV-FR-nn / NFR-10
```

Requires Node 22.5+ (uses the built-in `node:sqlite`, so there is no native build). Data lives in `data/inventory.db`.

Demo accounts (one per SDD §3 role): `staff/staff123`, `manager/manager123`, `owner/owner123`, `admin/admin123`.
Edit, delete and PO review are limited to Inventory Manager and System Administrator (FR14/FR15).

## Structure (NFR-09)

| Path | Tracker item |
|---|---|
| `src/db.js` | INV-ENT-01..04 schema, seed users, categories, fixed reorder qty |
| `src/services.js` | INV-LOG-01..06 (auth, BoM CRUD, stock engine, safety-stock monitor, auto-PO, search/filter) |
| `src/app.js` | Routes for INV-SCR-01..08, session + role middleware |
| `views/*.ejs`, `public/style.css` | Screens |
| `test/services.test.js` | Acceptance-criteria tests per FR, NFR-07 boundary, NFR-10 load |
| `scripts/seed-demo.js` | Demo data |

## Design decisions taken (tracker §4.3 — confirm with the team)

- **Storage:** SQLite (option A). Load test in `npm test` covers 1,000 BoMs / 10,000 transactions.
- **Reorder quantity:** fixed `FIXED_REORDER_QTY = 100` in `src/db.js`, or the shortfall if larger.
- **PO workflow:** review → confirm. One open PO per BoM; a new one is generated only after the previous is reviewed.
- **Categories:** predefined list in `src/db.js` (`CATEGORIES`).
- **Passwords:** bcryptjs. **Sessions:** express-session, in-memory (single-user v1.0). Set `SESSION_SECRET` in production.
- **Balances** change only through stock transactions; the Edit screen shows balance read-only (NFR-05).
- **Low stock** means `current_balance <= safety_stock_level` (FR10b/FR11, SDD FR-09).

## Not built (out of scope per BRD §3)

Payments, supplier management, barcode scanning, bulk import (SDD §8A deferred).
